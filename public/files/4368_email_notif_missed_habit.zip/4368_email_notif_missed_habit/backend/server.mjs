import mongoose from "mongoose";
import app from "./src/index.mjs";
const PORT = process.env.PORT || 1300;

const db = process.env.DB_URL.replace("<PASSWORD>", process.env.PASSWORD);
mongoose
  .connect(db)
  .then((con) => {
    console.log("Connected Successfully");
  })
  .catch((err) => {
    console.log(err);
  });

app.listen(PORT, () => console.log("Server Started"));

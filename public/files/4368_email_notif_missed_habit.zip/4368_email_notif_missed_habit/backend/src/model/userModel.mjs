// import { Mongoose } from "mongoose";
import validator from "validator";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";

const userSchema = mongoose.Schema({
	name: {
		type: String,
		required: [true, "Kindly insert the username"],
	},
	email: {
		type: String,
		required: [true, "Kindly insert the email"],
		unique: true,
		lowercase: true,
		validate: [validator.isEmail, "Please Provide Valid Enail"],
	},
	photo: {
		type: String,
	},
	role: {
		type: String,
		enum: ["admin", "user"],
		default: "user",
	},
	password: {
		type: String,
		required: [true, "Enter a valid password"],
		minlength: 8,
		select: false,
	},
	claimed: {
		type: Boolean,
		default: false,
	},
	lastDate: {
		type: Date,
	},
	userData: {
		type: Array,
		default: [],
	},
});

userSchema.pre("save", async function (next) {
	if (!this.isModified("password")) return next();

	this.password = await bcrypt.hash(this.password, 12);

	next();
});
userSchema.pre(/^find/, function (next) {
	this.find({ isActive: { $ne: false } });
	next();
});
userSchema.methods.comparePassword = async function (
	userPassword,
	candidatePassword
) {
	return await bcrypt.compare(userPassword, candidatePassword);
};
export const User = mongoose.model("SUser", userSchema);

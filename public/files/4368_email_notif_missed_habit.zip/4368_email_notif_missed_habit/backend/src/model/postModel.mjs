import mongoose from "mongoose";

const postSchema = new mongoose.Schema({
	title: {
		type: String,
		required: true,
	},
	user: {
		type: String,
		required: true,
	},
	desc: {
		type: String,
		required: true,
	},
	timing: {
		type: String,
	},
	img: {
		type: String,
	},
	completed: {
		type: Boolean,
		default: false,
	},
});

export const Post = mongoose.model("SPost", postSchema);

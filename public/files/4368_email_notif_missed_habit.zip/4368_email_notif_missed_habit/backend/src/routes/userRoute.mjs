import { Router } from "express";
import { login, protect, signup } from "../controller/authController.mjs";
import {
	deleteMe,
	updateMe,
	getUserData,
	sendReminder,
} from "../controller/userController.mjs";

const router = Router();

router.post("/signup", signup);
router.post("/login", login);
router.patch("/updateMe", protect, updateMe);
router.delete("/deleteMe", protect, deleteMe);
router.post("/remind", protect, sendReminder);
router.get("/", protect, getUserData);

export default router;

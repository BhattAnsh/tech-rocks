import { Router } from "express";
import {
  addPost,
  deletePostById,
  getAllPosts,
  getPostById,
  updatePostById,
} from "../controller/postController.mjs";
import { protect, restrict } from "../controller/authController.mjs";

const router = Router();

router.route("/").get(protect, getAllPosts).post(addPost);

router
  .route("/:id")
  .get(getPostById)
  .delete(protect, restrict("admin"), deletePostById)
  .patch(updatePostById);

export default router;

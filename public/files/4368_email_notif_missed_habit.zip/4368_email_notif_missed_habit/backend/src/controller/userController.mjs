import { User } from "../model/userModel.mjs";

import { sendEmail } from "../libs/nodemailer.mjs";

export const updateMe = async (req, res, next) => {
	//Create error if user post password data

	if (req.body.password || req.body.confirmPassword) {
		return res.status(401).json({
			status: "failed",
			message: "This route is not for password update",
		});
	}

	//Filter out the body
	const filteredBody = {
		...req.body,
	};

	console.log(filteredBody);
	//update the user

	const updatedUser = await User.findByIdAndUpdate(req.user.id, filteredBody, {
		new: true,
		runValidators: true,
	});
	//   console.log(updatedUser);

	//send updated user

	res.status(201).json({
		status: "succes",
		data: {
			user: updatedUser,
		},
	});
};

export const deleteMe = async (req, res, next) => {
	await User.findByIdAndUpdate(req.user.id, { isActive: false });
	res.status(201).json({ status: "succesfull" });
};

export const getUserData = async (req, res, next) => {
	const user = await User.findOne({ _id: req.user._id });
	res.status(201).json({ status: "succesfull", user });
};

export const sendReminder = async (req, res, next) => {
	const title = req.body.title;

	const user = await User.findOne({ _id: req.user._id });

	const body = "You missed a task to complete - " + title;
	const subject = "Habit Tracker: You missed a task today.";

	await sendEmail(user.email, subject, body);

	res.status(201).json({ status: "succesfull" });
};

// import { posts } from "../data/data.mjs";
import { Post } from "../model/postModel.mjs";

export const getAllPosts = async (req, res) => {
	const user_id = req.user._id;

	try {
		const posts = await Post.find({ user: user_id }).sort({ _id: -1 });

		// console.log(posts);
		res.status(201).send({
			status: "succes",
			data: {
				posts,
				username: req.user.name,
			},
		});
	} catch (err) {
		res.send({
			status: "fail",
		});
	}
};

export const addPost = async (req, res) => {
	try {
		const addedPost = await Post.create(req.body);
		res.send({
			status: "succesfull",
			addedPost,
		});
	} catch (err) {
		res.status(500).send({
			status: "failed",
			msg: err.message,
		});
	}
};

export const getPostById = async (req, res) => {
	try {
		const singlePost = await Post.findById(req.params.id);

		console.log(singlePost);
		//   const { params } = req;
		res.send(singlePost);
	} catch (err) {
		res.send({
			status: "error",
			msg: err.message,
		});
	}
};

export const deletePostById = async (req, res) => {
	try {
		const {
			params: { id },
		} = req;
		await Post.findByIdAndDelete(id);
		res.send("succesfull");
	} catch (err) {
		res.send({ status: "failed", message: err.message });
	}
};

export const updatePostById = async (req, res) => {
	try {
		const post = await Post.findByIdAndUpdate(req.params.id, req.body, {
			new: true,
			runValidators: true,
		});
		res.json({
			status: "succes",
			post,
		});
	} catch (err) {
		res.json({
			status: "fail",
			msg: err.message,
		});
	}
};

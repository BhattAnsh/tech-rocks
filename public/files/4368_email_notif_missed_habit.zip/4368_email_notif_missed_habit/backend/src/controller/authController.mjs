import { User } from "../model/userModel.mjs";
import jwt from "jsonwebtoken";
import util from "util";

const signToken = (id) =>
	jwt.sign({ id }, process.env.JWT_SECRET, {
		expiresIn: process.env.JWT_EXPIRE_IN,
	});

export const signup = async (req, res, next) => {
	try {
		const newUser = await User.create({
			name: req.body.name,
			email: req.body.email,
			password: req.body.password,
		});
		newUser.password = undefined;
		const token = signToken(newUser._id);
		res.status(200).json({
			status: "success",
			token,
			data: {
				user: newUser,
			},
		});
	} catch (err) {
		res.send({
			status: "failed",
			message: err.message,
		});
	}
};

export const login = async (req, res, next) => {
	try {
		//if username and password exists
		const { email, password } = req.body;
		if (!email || !password) {
			return res.send({
				status: "failed",
				message: "Enter email and password",
			});
		}

		//if user exits and password is correct

		const user = await User.findOne({ email }).select("+password");

		if (!user || !(await user.comparePassword(password, user.password))) {
			return res.send({
				status: "failed",
				message: "Email and password incorrect",
			});
		}

		// Send signed token
		const token = signToken(user._id);
		res.send({
			status: "success",
			user: { ...user._doc, password: null },
			token,
		});
	} catch (err) {
		res.status(400).send({
			status: "failed",
			message: err.message,
		});
	}
};

export const protect = async (req, res, next) => {
	try {
		let token;
		// Getting token and check if it exists

		if (
			req.headers.authorization &&
			req.headers.authorization.startsWith("Bearer")
		) {
			token = req.headers.authorization.split(" ")[1];
		}

		if (!token) {
			return res
				.status(401)
				.json({ status: "failed", message: "Token does not exist" });
		}
		// Verifying the token
		const { id } = await util.promisify(jwt.verify)(
			token,
			process.env.JWT_SECRET
		);

		// Check if user still exists
		const user = await User.findOne({ _id: id });
		// console.log(user);
		if (!user) {
			return res.status(401).json({
				status: "failed",
				message: "User is deleted",
			});
		}

		//If all ok then next
		req.user = user;
		next();
	} catch (err) {
		// console.error(err);
		return res
			.status(500)
			.json({ status: "error", message: "Not Authenticated" });
	}
};

export const restrict = (...roles) => {
	return (req, res, next) => {
		if (!roles.includes(req.user.role)) {
			return res.json({
				status: "failed",
				message: "This user not allowed to modify",
			});
		}
		next();
	};
};

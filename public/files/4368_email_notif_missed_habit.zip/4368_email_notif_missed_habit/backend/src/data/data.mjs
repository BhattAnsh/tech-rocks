export const users = [
  { id: 1, name: "Parth ", lastName: "Tiwari" },
  { id: 2, name: "Aman ", lastName: "Tiwari" },
  { id: 3, name: "Vartika ", lastName: "Triphati" },
];

export const posts = [
  {
    id: 1,
    title: "Blog API with Express",
    description: "A RESTful API built with Express.js for managing a blog.",
    author: "John Doe",
    created_at: new Date("2023-10-15T08:00:00Z"),
    tags: ["Express", "Node.js", "RESTful API", "MongoDB"],
  },
  {
    id: 2,
    title: "E-commerce Website Backend",
    description:
      "Backend system developed with Express.js for an e-commerce website.",
    author: "Jane Smith",
    created_at: new Date("2023-12-05T10:30:00Z"),
    tags: ["Express", "Node.js", "Backend Development", "MySQL"],
  },
  {
    id: 3,
    title: "Authentication Service",
    description:
      "A secure authentication service using Express.js and JWT for token-based authentication.",
    author: "Alex Johnson",
    created_at: new Date("2024-01-20T14:45:00Z"),
    tags: ["Express", "Node.js", "Authentication", "JWT"],
  },
];

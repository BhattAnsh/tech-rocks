import express from "express";
import postRouter from "./routes/postRoute.mjs";
import authRouter from "./routes/userRoute.mjs";
import { config } from "dotenv";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import mongoSanitize from "express-mongo-sanitize";
import hpp from "hpp";
import cors from "cors";
config();

const app = express();
app.use(cors());
//rate limiter
const limit = rateLimit({
	max: 1000,
	windowMs: 60 * 60 * 1000,
	message: "To many api request",
});

//limit the body
app.use(express.json({ limit: "10kb" }));

//secure headers
app.use(helmet());

//sanatize the body data from injection attacks
app.use(mongoSanitize());

//param pollution
app.use(hpp());

//rate limiter
app.use("/api", limit);

////////////////
app.use("/api/posts", postRouter);
app.use("/api/user", authRouter);

export default app;

export const habitData = [
  {
    id: 1,
    title: "Reading Book",
    time: "7:30-10:30",
    img: "/images/watch.png",
  },
  { id: 2, title: "Eating Food", time: "7:30-10:30", img: "/images/watch.png" },
  {
    id: 3,
    title: "Reading Book",
    time: "7:30-10:30",
    img: "/images/watch.png",
  },
  {
    id: 4,
    title: "Reading Book",
    time: "7:30-10:30",
    img: "/images/watch.png",
  },
  {
    id: 5,
    title: "Reading Book",
    time: "7:30-10:30",
    img: "/images/watch.png",
  },
  {
    id: 6,
    title: "Reading Book",
    time: "7:30-10:30",
    img: "/images/watch.png",
  },
];

import axios from "../libs/axios";
import { getAuthHeader } from "../libs/axios";
export async function registerUser(
	body = {
		name: "",
		email: "",
		password: "",
	}
) {
	const { data } = await axios.post("user/signup", body);
	return data;
}

export async function loginUser(
	body = {
		email: "",
		password: "",
	}
) {
	const { data } = await axios.post("user/login", body);
	return data;
}

export async function updateUser(
	body = {
		claimed: true,
	}
) {
	const { data } = await axios.patch("user/updateMe", body, {
		headers: {
			...getAuthHeader(),
		},
	});
	return data;
}

export async function getUserData() {
	const { data } = await axios.get("user", {
		headers: {
			...getAuthHeader(),
		},
	});
	return data;
}

export async function remindUser(
	body = {
		title: "",
	}
) {
	const { data } = await axios.post("user/remind", body, {
		headers: {
			...getAuthHeader(),
		},
	});
	return data;
}

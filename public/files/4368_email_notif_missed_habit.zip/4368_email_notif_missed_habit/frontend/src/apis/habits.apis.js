import axios from "../libs/axios";
import * as storageUtils from "../utils/storage";
import { getAuthHeader } from "../libs/axios";

export async function addHabit(
	body = {
		title: "",
		desc: "",
		timing: "",
	}
) {
	const userData = storageUtils.getUser();

	const { data } = await axios.post(
		"posts",
		{
			...body,
			user: userData._id,
		},
		{
			headers: {
				...getAuthHeader(),
			},
		}
	);

	return data;
}

export async function getUserHabits() {
	const { data } = await axios.get("posts", {
		headers: {
			...getAuthHeader(),
		},
	});
	return data;
}

export async function updateHabit(
	body = {
		completed: true,
	},
	habitId
) {
	const { data } = await axios.patch("posts/" + habitId, body, {
		headers: {
			...getAuthHeader(),
		},
	});

	return data;
}

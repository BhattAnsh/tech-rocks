import { toast } from "react-toastify";

export function getCurrentDate() {
	const now = new Date();
	const year = now.getFullYear();
	const month = String(now.getMonth() + 1).padStart(2, "0");
	const day = String(now.getDate()).padStart(2, "0");
	return `${year}-${month}-${day}`;
}

export const APIerrorMessageHandler = (error) => {
	if (error?.response?.data?.message || error?.response?.data?.msg) {
		alert(error?.response?.data?.message || error?.response?.data?.msg);
		return;
	}
	if (error.message) {
		alert(error.message);
		return;
	}
	console.log(error);
	alert("something went wrong!");
};

const KEYS = {
  USER_TOKEN: "habit_tracker_pro@token",
  USER: "habit_tracker_pro@user",
};

export const getToken = () => {
  return localStorage.getItem(KEYS.USER_TOKEN);
};

export const setToken = (token) => {
  return localStorage.setItem(KEYS.USER_TOKEN, token);
};

export const getUser = () => {
  const strData = localStorage.getItem(KEYS.USER);
  return strData ? JSON.parse(strData) : null;
};

export const setUser = (data = {}) => {
  localStorage.setItem(KEYS.USER, JSON.stringify(data));
};

export const logoutUser = () => {
  localStorage.removeItem(KEYS.USER);
  localStorage.removeItem(KEYS.USER_TOKEN);
  localStorage.removeItem("lastDate");
};

/* eslint-disable react/prop-types */
import { useEffect, useState } from "react";
import Header from "../Components/Header";

// import { habitData } from "./data/habitData";
import Model from "../Components/Model";
import Reward from "../Components/Reward";
import { useHabitContext } from "../Context/DataContext";
import { useAuthContext } from "../Context/AuthContext";

import { remindUser } from "../apis/user.apis";

const apiHits = {};

export default function HomePage() {
	const { habitData, isClaimed, setClaimed, updateHabitData } =
		useHabitContext();

	const { isAuth } = useAuthContext();
	const [error, setError] = useState(false);
	const [allCompleted, setAllCompleted] = useState(false);
	useEffect(() => {
		if (habitData.length) {
			// Check if all habits are completed
			const areAllCompleted = habitData.every((habit) => habit.completed);

			// Update allCompleted state
			setAllCompleted(areAllCompleted);
		}
	}, [habitData]);

	useEffect(() => {
		const checkAndSendAPI = async () => {
			const currentTime = new Date();
			const currentHours = currentTime.getHours();
			const currentMinutes = currentTime.getMinutes();

			habitData.map(async (item) => {
				if (!item.completed && !apiHits[item.id]) {
					const [itemHours, itemMinutes] = item.timing.split(":").map(Number);
					if (
						currentHours > itemHours ||
						(currentHours === itemHours && currentMinutes > itemMinutes)
					) {
						try {
							await remindUser({ title: item.title });
							apiHits[item.id] = true;
						} catch (error) {
							console.error(
								`Failed to send API request for item ${item.id}:`,
								error
							);
						}
					}
				}
				return item;
			});
		};

		checkAndSendAPI();
	}, [habitData]);

	console.log(habitData);

	return (
		<main>
			<Header />
			{error ? (
				<div className="toast">
					<div className="alert alert-info">
						<span>Kindly Login First</span>
					</div>
				</div>
			) : null}
			{allCompleted && isClaimed === false ? (
				<Reward setAllCompleted={setAllCompleted} setClaimed={setClaimed} />
			) : null}

			<section className="mainData mx-5">
				<div className="titleContainer flex justify-between mt-5 ">
					<h1 className="text-5xl ">Today Activities</h1>
					<Model allCompleted={allCompleted} setClaimed={setClaimed} />
				</div>
				<span className="ml-2 mt-2">Manage your habits</span>

				{/* Habits list */}

				<div className="habitContainer mt-14">
					<h2 className="text-3xl mb-6">Your Habits</h2>

					<ul className="flex gap-8 flex-wrap">
						{habitData.map((item) => (
							<ListCard
								key={item.id}
								item={item}
								isAuth={isAuth}
								setError={setError}
							/>
						))}
					</ul>
				</div>
			</section>
		</main>
	);
}

// function ListCard({ item }) {
//   return (
//     <li className=" card p-3 shadow-lg text-base-300 rounded-xl bg-base-content flex flex-col items-center gap-2 ">
//       <img className=" h-36  rounded-2xl" src={item.img} alt="" />
//       <p className="text-xl font-semibold">{item.title}</p>
//       <p className="text-base-100">{item.time}</p>
//     </li>
//   );
// }

function ListCard({ item, isAuth, setError }) {
	const { markAsComplete } = useHabitContext();
	function handleComplete() {
		if (isAuth) markAsComplete(item.id);
		else {
			setError(true);
		}
	}

	return (
		<div className="card card-compact w-72  bg-base-content text-base-100 shadow-xl transition-transform hover:scale-105 duration-500">
			<figure>
				<img src={item.img} alt="Shoes" />
			</figure>
			<div className="card-body">
				<h2 className="card-title">{item.title}</h2>
				<p>{item.desc}</p>
				<p className="mt-3">{item.timing}</p>
				<div className="card-actions justify-end">
					{item.completed === false ? (
						<button onClick={handleComplete} className=" mt-2 btn btn-primary">
							Mark as Complete
						</button>
					) : (
						<button className=" mt-2 btn btn-secondary">Completed</button>
					)}
				</div>
			</div>
		</div>
	);
}

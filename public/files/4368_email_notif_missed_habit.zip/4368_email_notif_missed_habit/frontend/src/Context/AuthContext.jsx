/* eslint-disable react/prop-types */
import { createContext, useContext, useEffect, useState } from "react";
import * as storageUtils from "../utils/storage";

const AuthContext = createContext();

export const useAuthContext = () => useContext(AuthContext);

export default function AuthProvider({ children }) {
	const [isAuth, setAuth] = useState(Boolean(storageUtils.getToken()) || false);
	const [user, setUser] = useState(storageUtils.getUser());
	// useEffect(() => {
	//   localStorage.setItem("user", JSON.stringify(user));
	//   localStorage.setItem("isAuth", JSON.stringify(isAuth));
	// }, [user, isAuth]);
	return (
		<AuthContext.Provider value={{ isAuth, setAuth, setUser, user }}>
			{children}
		</AuthContext.Provider>
	);
}

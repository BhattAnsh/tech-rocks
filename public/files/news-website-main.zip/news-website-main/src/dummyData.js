export const hero = [
  {
    id: 1,
    cover: "../images/hero/hero1.jpg",
    catgeory: "featured",
    title:
      "Rishi Sunak: I inherited ‘worst hospital pass’ for a new PM in decades",

    time: "5 Jun - 2022",
    desc: [
      {
        para1:
          "You audience. Least, the recently his repeat the this avarice for the have and was on would before the concise bedding were hall politely name be regretting have of even five of it the his are there again. Word seven designer far lady problem will have work with you to fully understand your business to achieve.",
      },
      {
        para2:
          "We work with clients big and small across a range of sectors and we utilize all forms of media to get your name out there in a way that’s right for you. We believe that analysis of your company and your customers is key in responding effectively to your promotional needs and we will work with you.",
      },
      {
        para3:
          "We have a number of different teams within our agency that specialise in different areas of business so you can be sure that you won’t receive a generic service and although we can’t boast years and years of service we can ensure you that is a good thing in this industry.",
      },
    ],
    details: [
      {
        title: "Starting a new company is easy",
      },
      {
        para1:
          "Our teams are up to date with the latest technologies, media trends and are keen to prove themselves in this industry and that’s what you want from an advertising agency, not someone who is relying on the same way of doing things that worked 10 years, 5 years or even a year ago.",
      },
      {
        quote:
          "Scarfs, still not this no with explains it me and option on the any options roasted when I and state can that an don't subjective of has his take on and in from royal everything took raising our have behind success you the mechanic.",
      },
      {
        para2:
          "And, higher by agency; In from their in and we spirit, through merely and doctor's small him sounded a all now, with that put gift white highly geared that was left back as of or logged important. A over have the large try understanding the believe. Perfected been viewer. Shreds early willingly safely what passion the.",
      },
      {
        para3:
          "In an ideal world this website wouldn’t exist, a client would acknowledge the importance of having web copy before the design starts. Needless to say it’s very important, content is king and people are beginning to understand that. However, back over in reality some project schedules and budgets don’t allow for web copy to be written before the design phase, this is sad but true.",
      },
    ],
  },
  {
    id: 2,
    cover: "../images/hero/hero2.jpg",
    catgeory: "Week-In-Review",
    title:
      "Sunak’s moment of maximum danger may still await — the Reform-Conservative crossover",
    authorName: "Politics.co.uk staff",

    desc: [
      {
        para1:
          "You audience. Least, the recently his repeat the this avarice for the have and was on would before the concise bedding were hall politely name be regretting have of even five of it the his are there again. Word seven designer far lady problem will have work with you to fully understand your business to achieve.",
      },
      {
        para2:
          "We work with clients big and small across a range of sectors and we utilize all forms of media to get your name out there in a way that’s right for you. We believe that analysis of your company and your customers is key in responding effectively to your promotional needs and we will work with you.",
      },
      {
        para3:
          "We have a number of different teams within our agency that specialise in different areas of business so you can be sure that you won’t receive a generic service and although we can’t boast years and years of service we can ensure you that is a good thing in this industry.",
      },
    ],
    details: [
      {
        title: "Starting a new company is easy",
      },
      {
        para1:
          "Our teams are up to date with the latest technologies, media trends and are keen to prove themselves in this industry and that’s what you want from an advertising agency, not someone who is relying on the same way of doing things that worked 10 years, 5 years or even a year ago.",
      },
      {
        quote:
          "Scarfs, still not this no with explains it me and option on the any options roasted when I and state can that an don't subjective of has his take on and in from royal everything took raising our have behind success you the mechanic.",
      },
      {
        para2:
          "And, higher by agency; In from their in and we spirit, through merely and doctor's small him sounded a all now, with that put gift white highly geared that was left back as of or logged important. A over have the large try understanding the believe. Perfected been viewer. Shreds early willingly safely what passion the.",
      },
      {
        para3:
          "In an ideal world this website wouldn’t exist, a client would acknowledge the importance of having web copy before the design starts. Needless to say it’s very important, content is king and people are beginning to understand that. However, back over in reality some project schedules and budgets don’t allow for web copy to be written before the design phase, this is sad but true.",
      },
    ],
  },
  {
    id: 3,
    cover: "../images/hero/hero3.jpg",
    catgeory: "New-Feature",
    title:
      "The ‘Blue Wells’: 42 Conservative strongholds that could fall at the next election",
    authorName: "Politics.co.uk staff",
    authorImg: "../images/author.jpg",
    time: "22 Mar - 2022",
    desc: [
      {
        para1:
          "You audience. Least, the recently his repeat the this avarice for the have and was on would before the concise bedding were hall politely name be regretting have of even five of it the his are there again. Word seven designer far lady problem will have work with you to fully understand your business to achieve.",
      },
      {
        para2:
          "We work with clients big and small across a range of sectors and we utilize all forms of media to get your name out there in a way that’s right for you. We believe that analysis of your company and your customers is key in responding effectively to your promotional needs and we will work with you.",
      },
      {
        para3:
          "We have a number of different teams within our agency that specialise in different areas of business so you can be sure that you won’t receive a generic service and although we can’t boast years and years of service we can ensure you that is a good thing in this industry.",
      },
    ],
    details: [
      {
        title: "Starting a new company is easy",
      },
      {
        para1:
          "Our teams are up to date with the latest technologies, media trends and are keen to prove themselves in this industry and that’s what you want from an advertising agency, not someone who is relying on the same way of doing things that worked 10 years, 5 years or even a year ago.",
      },
      {
        quote:
          "Scarfs, still not this no with explains it me and option on the any options roasted when I and state can that an don't subjective of has his take on and in from royal everything took raising our have behind success you the mechanic.",
      },
      {
        para2:
          "And, higher by agency; In from their in and we spirit, through merely and doctor's small him sounded a all now, with that put gift white highly geared that was left back as of or logged important. A over have the large try understanding the believe. Perfected been viewer. Shreds early willingly safely what passion the.",
      },
      {
        para3:
          "In an ideal world this website wouldn’t exist, a client would acknowledge the importance of having web copy before the design starts. Needless to say it’s very important, content is king and people are beginning to understand that. However, back over in reality some project schedules and budgets don’t allow for web copy to be written before the design phase, this is sad but true.",
      },
    ],
  },
  {
    id: 4,
    cover: "../images/hero/hero4.jpg",
    catgeory: "5 Minute Read",
    title: "Could Robert Jenrick be the next Conservative Party leader?",
    authorName: "sunil",
    authorImg: "../images/author.jpg",
    time: "08 Dec - 2022",
    desc: [
      {
        para1:
          "You audience. Least, the recently his repeat the this avarice for the have and was on would before the concise bedding were hall politely name be regretting have of even five of it the his are there again. Word seven designer far lady problem will have work with you to fully understand your business to achieve.",
      },
      {
        para2:
          "We work with clients big and small across a range of sectors and we utilize all forms of media to get your name out there in a way that’s right for you. We believe that analysis of your company and your customers is key in responding effectively to your promotional needs and we will work with you.",
      },
      {
        para3:
          "We have a number of different teams within our agency that specialise in different areas of business so you can be sure that you won’t receive a generic service and although we can’t boast years and years of service we can ensure you that is a good thing in this industry.",
      },
    ],
    details: [
      {
        title: "Starting a new company is easy",
      },
      {
        para1:
          "Our teams are up to date with the latest technologies, media trends and are keen to prove themselves in this industry and that’s what you want from an advertising agency, not someone who is relying on the same way of doing things that worked 10 years, 5 years or even a year ago.",
      },
      {
        quote:
          "Scarfs, still not this no with explains it me and option on the any options roasted when I and state can that an don't subjective of has his take on and in from royal everything took raising our have behind success you the mechanic.",
      },
      {
        para2:
          "And, higher by agency; In from their in and we spirit, through merely and doctor's small him sounded a all now, with that put gift white highly geared that was left back as of or logged important. A over have the large try understanding the believe. Perfected been viewer. Shreds early willingly safely what passion the.",
      },
      {
        para3:
          "In an ideal world this website wouldn’t exist, a client would acknowledge the importance of having web copy before the design starts. Needless to say it’s very important, content is king and people are beginning to understand that. However, back over in reality some project schedules and budgets don’t allow for web copy to be written before the design phase, this is sad but true.",
      },
    ],
  },
];

export const popular = [
  {
    id: 1,
    catgeory: "Sponsored",
    title: "How the UK regulates sports betting",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/sponsored/sp1.jpeg",
    desc: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis Theme natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna.",
  },
  {
    id: 2,
    catgeory: "Opinion Former Comment",
    title:
      "The ‘to-do’ list: how the government can deliver for doctors before the next election",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/sponsored/sp2.jpeg",
    desc: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis Theme natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna.",
  },
  {
    id: 3,
    catgeory: "Opinion Former Comment",
    title: "Uncovering the regional ‘retirement readiness’ gaps in the UK",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/sponsored/sp3.jpeg",

    desc: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis Theme natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna.",
  },
  {
    id: 4,
    catgeory: "Opinion Former Comment",
    title: "Happy Birthday NHS",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/sponsored/sp4.jpeg",

    desc: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis Theme natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna.",
  },
  {
    id: 21,
    catgeory: "politics",
    title:
      "PMQs verdict: The Conservative Party refuses to rally behind Rishi Sunak",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/ppost/pop1.jpg",
    desc: "Description of the news feature...",
  },
  {
    id: 22,
    catgeory: "politics",
    title:
      "Week-in-Review: The Conservative Party has come to terms with its malaise",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/ppost/pop2.jpeg",
    desc: "Description of the news feature...",
  },
  {
    id: 23,
    catgeory: "politics",
    title: "Will Blur drummer Dave Rowntree win for Labour in Mid Sussex?",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/ppost/pop3.jpeg",
    desc: "Description of the news feature...",
  },
  {
    id: 24,
    catgeory: "politics",
    title:
      "Budget verdict: Jeremy Hunt’s offering will prove no election springboard",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/ppost/pop4.jpeg",
    desc: "Description of the news feature...",
  },
  {
    id: 25,
    catgeory: "Comment",
    title: "Mel Stride’s approach to mental health is blissfully ignorant",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/life/life5.jpeg",

    desc: "Description of the news feature...",
  },
  {
    id: 26,
    catgeory: "Comment",
    title:
      "Government interference with Telegraph takeover sets worrying precedent for press freedom",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/life/life2.jpeg",

    desc: "Description of the news feature...",
  },

  {
    id: 28,
    catgeory: "MP Comment",
    title:
      "Wendy Chamberlain: ‘It’s time to address the barriers to a fair election — starting with voter ID’",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/life/life3.jpeg",

    desc: "Description of the news feature...",
  },
  {
    id: 29,
    catgeory: "MP Comment",
    title:
      "MP Comment: Peter Gibson: ‘We must do more to achieve zero transmissions of HIV by 2030’",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/life/life4.jpeg",

    desc: "Description of the news feature...",
  },
];

export const sponsored = [
  {
    id: 1,
    catgeory: "Sponsored",
    title: "How the UK regulates sports betting",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/sponsored/sp1.jpeg",
    desc: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis Theme natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna.",
  },
  {
    id: 31,
    catgeory: "Opinion Former Comment",
    title:
      "The ‘to-do’ list: how the government can deliver for doctors before the next election",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/sponsored/sp2.jpeg",

    desc: "Description of the news feature...",
  },
  {
    id: 32,
    catgeory: "Opinion Former Comment",
    title: "Uncovering the regional ‘retirement readiness’ gaps in the UK",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/sponsored/sp3.jpeg",

    desc: "Description of the news feature...",
  },
  {
    id: 33,
    catgeory: "Opinion Former Comment",
    title: "Happy Birthday NHS",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/sponsored/sp4.jpeg",

    desc: "Description of the news feature...",
  },
];

export const ppost = [
  {
    id: 21,
    catgeory: "politics",
    title:
      "PMQs verdict: The Conservative Party refuses to rally behind Rishi Sunak",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/ppost/pop1.jpg",
    desc: "Description of the news feature...",
  },
  {
    id: 22,
    catgeory: "politics",
    title:
      "Week-in-Review: The Conservative Party has come to terms with its malaise",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/ppost/pop2.jpeg",
    desc: "Description of the news feature...",
  },
  {
    id: 23,
    catgeory: "politics",
    title: "Will Blur drummer Dave Rowntree win for Labour in Mid Sussex?",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/ppost/pop3.jpeg",
    desc: "Description of the news feature...",
  },
  {
    id: 24,
    catgeory: "politics",
    title:
      "Budget verdict: Jeremy Hunt’s offering will prove no election springboard",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/ppost/pop4.jpeg",
    desc: "Description of the news feature...",
  },
];
export const lifestyle = [
  {
    id: 25,
    catgeory: "Comment",
    title: "Mel Stride’s approach to mental health is blissfully ignorant",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/life/life5.jpeg",

    desc: "Description of the news feature...",
  },
  {
    id: 26,
    catgeory: "Comment",
    title:
      "Government interference with Telegraph takeover sets worrying precedent for press freedom",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/life/life2.jpeg",

    desc: "Description of the news feature...",
  },

  {
    id: 28,
    catgeory: "MP Comment",
    title:
      "Wendy Chamberlain: ‘It’s time to address the barriers to a fair election — starting with voter ID’",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/life/life3.jpeg",

    desc: "Description of the news feature...",
  },
  {
    id: 29,
    catgeory: "MP Comment",
    title:
      "MP Comment: Peter Gibson: ‘We must do more to achieve zero transmissions of HIV by 2030’",
    date: "6 April 2024",
    comments: 0,
    cover: "../images/life/life4.jpeg",

    desc: "Description of the news feature...",
  },
];
export const tpost = [
  {
    id: 1,
    title:
      "When is the next UK general election When is the next general election? The viable dates Rishi Sunak will be considering",
    cover: "../images/tpost/tp1.jpeg",
  },
  {
    id: 2,
    title: "Could Robert Jenrick be the next Conservative Party leader?",
    cover: "../images/tpost/tp2.jpeg",
  },
  {
    id: 3,
    title: " What’s at stake in the Kingswood and Wellingborough by-elections?",
    cover: "../images/tpost/tp3.jpeg",
  },
];
